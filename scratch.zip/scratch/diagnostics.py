import sys, json
try:
    import rasterio
    rasterio_version = rasterio.__version__
    gdal_version = rasterio.__gdal_version__
except Exception as e:
    rasterio_version = None
    gdal_version = None
    err = str(e)
else:
    err = None
info = {
    "python_executable": sys.executable,
    "python_version": sys.version.split('\n')[0],
    "rasterio_version": rasterio_version,
    "gdal_version": gdal_version,
    "error": err,
}
print(json.dumps(info))
