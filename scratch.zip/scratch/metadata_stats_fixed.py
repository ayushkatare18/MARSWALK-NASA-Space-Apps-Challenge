import rasterio, numpy as np, json

dem_path = r'C:\Users\ayush\Downloads\MARSWALK\JEZ_hirise_soc_006_DTM_MOLAtopography_DeltaGeoid_1m_Eqc_latTs0_lon0_blend40.tif'
cost_path = r'C:\Users\ayush\Downloads\MARSWALK\MARSWALK_DATA\processed\jezero\jezero_cost_450e0d0d_f2d7519a.tif'

def get_meta(path):
    with rasterio.open(path) as src:
        meta = {
            'path': src.name,
            'width': src.width,
            'height': src.height,
            'crs': src.crs.to_string() if src.crs else None,
            'dtype': src.dtypes[0],
            'nodata': src.nodata,
            'transform': list(src.transform)
        }
    return meta

def cost_std_welford(path, nodata):
    with rasterio.open(path) as src:
        count = 0
        mean = 0.0
        M2 = 0.0
        for row in range(0, src.height, 1024):
            h = min(1024, src.height - row)
            for col in range(0, src.width, 1024):
                w = min(1024, src.width - col)
                window = rasterio.windows.Window(col, row, w, h)
                data = src.read(1, window=window, boundless=True, fill_value=nodata)
                valid = data[data != nodata]
                for val in valid:
                    count += 1
                    delta = val - mean
                    mean += delta / count
                    delta2 = val - mean
                    M2 += delta * delta2
        variance = M2 / (count - 1) if count > 1 else 0.0
        std = variance ** 0.5
    return {'mean': mean, 'std': std, 'count': count}

# Gather metadata
 dem_meta = get_meta(dem_path)
 cost_meta = get_meta(cost_path)

# Cost statistics (robust percentiles via downsampling)
 cost_nodata = cost_meta['nodata'] if cost_meta['nodata'] is not None else 255
FACTOR = 8
with rasterio.open(cost_path) as src:
    out_h = max(1, src.height // FACTOR)
    out_w = max(1, src.width // FACTOR)
    ds = src.read(1, out_shape=(out_h, out_w), resampling=rasterio.enums.Resampling.average)
    valid = ds[ds != cost_nodata]
    cost_min = float(valid.min())
    cost_max = float(valid.max())
    cost_mean = float(valid.mean())
    perc = list(np.percentile(valid, [2,5,50,95,98]))

std_info = cost_std_welford(cost_path, cost_nodata)

output = {
    'dem': dem_meta,
    'cost': cost_meta,
    'cost_stats': {
        'min': cost_min,
        'max': cost_max,
        'mean': cost_mean,
        'std': std_info['std'],
        'percentiles': perc,
        'valid_pixel_count': std_info['count']
    }
}
print(json.dumps(output))
