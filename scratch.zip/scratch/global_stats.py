import rasterio, numpy as np, json, sys

dem_path = r'C:\Users\ayush\Downloads\MARSWALK\JEZ_hirise_soc_006_DTM_MOLAtopography_DeltaGeoid_1m_Eqc_latTs0_lon0_blend40.tif'
cost_path = r'C:\Users\ayush\Downloads\MARSWALK\MARSWALK_DATA\processed\jezero\jezero_cost_450e0d0d_f2d7519a.tif'

block_size = 1024  # pixels

def compute_stats(path, nodata):
    with rasterio.open(path) as src:
        width, height = src.width, src.height
        mins = []
        maxs = []
        total = 0.0
        total_sq = 0.0
        count = 0
        values = []  # store valid values for percentiles (may be large)
        for row in range(0, height, block_size):
            h = min(block_size, height - row)
            for col in range(0, width, block_size):
                w = min(block_size, width - col)
                window = rasterio.windows.Window(col, row, w, h)
                data = src.read(1, window=window, boundless=True, fill_value=nodata)
                valid = data[data != nodata]
                if valid.size == 0:
                    continue
                mins.append(valid.min())
                maxs.append(valid.max())
                total += valid.sum()
                total_sq += (valid**2).sum()
                count += valid.size
                values.append(valid)
        global_min = float(min(mins)) if mins else None
        global_max = float(max(maxs)) if maxs else None
        mean = float(total / count) if count else None
        std = float(((total_sq / count) - (mean**2))**0.5) if count else None
        all_vals = np.concatenate(values) if values else np.array([])
        percentiles = None
        if all_vals.size > 0:
            percentiles = list(np.percentile(all_vals, [2,5,50,95,98]))
        return {
            'min': global_min,
            'max': global_max,
            'mean': mean,
            'std': std,
            'percentiles': percentiles,
            'count': count
        }

# Determine nodata values from raster metadata
with rasterio.open(dem_path) as src:
    dem_nodata = src.nodata if src.nodata is not None else -9999
with rasterio.open(cost_path) as src:
    cost_nodata = src.nodata if src.nodata is not None else 255

dem_stats = compute_stats(dem_path, dem_nodata)
cost_stats = compute_stats(cost_path, cost_nodata)
print(json.dumps({'dem': dem_stats, 'cost': cost_stats}))
