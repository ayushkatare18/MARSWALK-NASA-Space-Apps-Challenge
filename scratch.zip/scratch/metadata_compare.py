import os, json, rasterio
from osgeo import gdal

dem_path = r'C:\Users\ayush\Downloads\MARSWALK\JEZ_hirise_soc_006_DTM_MOLAtopography_DeltaGeoid_1m_Eqc_latTs0_lon0_blend40.tif'
cost_path = r'C:\Users\ayush\Downloads\MARSWALK\MARSWALK_DATA\processed\jezero\jezero_cost_450e0d0d_f2d7519a.tif'

def rasterio_info(path):
    with rasterio.open(path) as src:
        return {
            'width': src.width,
            'height': src.height,
            'crs': src.crs.to_string() if src.crs else None,
            'crs_wkt': src.crs.wkt if src.crs else None,
            'transform': list(src.transform),
            'dtype': src.dtypes[0],
            'count': src.count,
            'nodata': src.nodata,
            'driver': src.driver,
            'file_size_bytes': os.path.getsize(path)
        }

def gdal_info(path):
    ds = gdal.Open(path)
    if ds is None:
        raise RuntimeError(f'GDAL cannot open {path}')
    proj = ds.GetProjection()
    gt = ds.GetGeoTransform()
    return {
        'proj_wkt': proj,
        'geotransform': gt,
        'raster_xsize': ds.RasterXSize,
        'raster_ysize': ds.RasterYSize,
        'band_count': ds.RasterCount,
        'driver': ds.GetDriver().ShortName,
        'file_size_bytes': os.path.getsize(path)
    }

out = {
    'dem': {
        'rasterio': rasterio_info(dem_path),
        'gdal': gdal_info(dem_path)
    },
    'cost': {
        'rasterio': rasterio_info(cost_path),
        'gdal': gdal_info(cost_path)
    }
}
print(json.dumps(out, indent=2))
