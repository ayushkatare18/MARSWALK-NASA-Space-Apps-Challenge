import rasterio, numpy as np, json

dem_path = r'C:\Users\ayush\Downloads\MARSWALK\JEZ_hirise_soc_006_DTM_MOLAtopography_DeltaGeoid_1m_Eqc_latTs0_lon0_blend40.tif'
cost_path = r'C:\Users\ayush\Downloads\MARSWALK\MARSWALK_DATA\processed\jezero\jezero_cost_450e0d0d_f2d7519a.tif'

def get_meta(path):
    with rasterio.open(path) as src:
        return {
            'path': src.name,
            'width': src.width,
            'height': src.height,
            'crs': src.crs.to_string() if src.crs else None,
            'dtype': src.dtypes[0],
            'nodata': src.nodata,
            'transform': list(src.transform)
        }

def welford_std(path, nodata):
    with rasterio.open(path) as src:
        count = 0
        mean = 0.0
        M2 = 0.0
        for row in range(0, src.height, 1024):
            h = min(1024, src.height - row)
            for col in range(0, src.width, 1024):
                w = min(1024, src.width - col)
                window = rasterio.windows.Window(col, row, w, h)
                data = src.read(1, window=window, boundless=True, fill_value=nodata)
                valid = data[data != nodata]
                for v in valid:
                    count += 1
                    delta = v - mean
                    mean += delta / count
                    delta2 = v - mean
                    M2 += delta * delta2
        variance = M2 / (count - 1) if count > 1 else 0.0
        return {'mean': mean, 'std': variance ** 0.5, 'count': count}

dem_meta = get_meta(dem_path)
cost_meta = get_meta(cost_path)

# Cost stats: downsample for percentiles
cost_nodata = cost_meta['nodata'] if cost_meta['nodata'] is not None else 255
FACTOR = 8
with rasterio.open(cost_path) as src:
    out_h = max(1, src.height // FACTOR)
    out_w = max(1, src.width // FACTOR)
    ds = src.read(1, out_shape=(out_h, out_w), resampling=rasterio.enums.Resampling.average)
    valid = ds[ds != cost_nodata]
    cost_min = float(valid.min())
    cost_max = float(valid.max())
    cost_mean = float(valid.mean())
    cost_perc = list(np.percentile(valid, [2,5,50,95,98]))

cost_stats = welford_std(cost_path, cost_nodata)

output = {
    'dem': dem_meta,
    'cost': cost_meta,
    'cost_stats': {
        'min': cost_min,
        'max': cost_max,
        'mean': cost_mean,
        'std': cost_stats['std'],
        'percentiles': cost_perc,
        'valid_pixel_count': cost_stats['count']
    }
}
print(json.dumps(output))
