import rasterio, numpy as np, json, sys

dem_path = r'C:\Users\ayush\Downloads\MARSWALK\JEZ_hirise_soc_006_DTM_MOLAtopography_DeltaGeoid_1m_Eqc_latTs0_lon0_blend40.tif'
cost_path = r'C:\Users\ayush\Downloads\MARSWALK\MARSWALK_DATA\processed\jezero\jezero_cost_450e0d0d_f2d7519a.tif'

tile_x = 40
tile_y = 40
size = 256
col_off = tile_x * size
row_off = tile_y * size
win = rasterio.windows.Window(col_off, row_off, size, size)

def stats(path, nodata):
    with rasterio.open(path) as src:
        data = src.read(1, window=win, boundless=True, fill_value=nodata)
        valid = data[data != nodata]
        if valid.size == 0:
            return None
        return {
            'min': float(valid.min()),
            'max': float(valid.max()),
            'mean': float(valid.mean()),
            'std': float(valid.std()),
            'percentiles': list(np.percentile(valid, [2,5,50,95,98]))
        }

dem_stats = stats(dem_path, -9999)
cost_stats = stats(cost_path, 255)
print(json.dumps({'dem': dem_stats, 'cost': cost_stats}))
