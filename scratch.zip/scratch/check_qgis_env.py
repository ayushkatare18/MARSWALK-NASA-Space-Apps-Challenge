import fastapi, uvicorn, rasterio, sys
print('FastAPI', getattr(fastapi, '__version__', 'unknown'))
print('Uvicorn', getattr(uvicorn, '__version__', 'unknown'))
print('Rasterio', getattr(rasterio, '__version__', 'unknown'))
print('Python', sys.version)
