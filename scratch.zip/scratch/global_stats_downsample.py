import rasterio, numpy as np, json, os

dem_path = r'C:\Users\ayush\Downloads\MARSWALK\JEZ_hirise_soc_006_DTM_MOLAtopography_DeltaGeoid_1m_Eqc_latTs0_lon0_blend40.tif'
cost_path = r'C:\Users\ayush\Downloads\MARSWALK\MARSWALK_DATA\processed\jezero\jezero_cost_450e0d0d_f2d7519a.tif'

# Downsampling factor for percentile estimation (must be integer divisor of dimensions)
FACTOR = 8

def stats_downsample(path, nodata, factor):
    with rasterio.open(path) as src:
        # compute downsampled shape
        out_height = max(1, src.height // factor)
        out_width = max(1, src.width // factor)
        data = src.read(
            1,
            out_shape=(out_height, out_width),
            resampling=rasterio.enums.Resampling.average,
        )
        # mask nodata
        mask = data == nodata
        valid = data[~mask]
        if valid.size == 0:
            return None
        mn = float(valid.min())
        mx = float(valid.max())
        mean = float(valid.mean())
        std = float(valid.std())
        perc = list(np.percentile(valid, [2,5,50,95,98]))
        return {'min': mn, 'max': mx, 'mean': mean, 'std': std, 'percentiles': perc}

# Get nodata from metadata
with rasterio.open(dem_path) as src:
    dem_nodata = src.nodata if src.nodata is not None else -9999
with rasterio.open(cost_path) as src:
    cost_nodata = src.nodata if src.nodata is not None else 255

dem_stats = stats_downsample(dem_path, dem_nodata, FACTOR)
cost_stats = stats_downsample(cost_path, cost_nodata, FACTOR)

out_path = r'C:\Users\ayush\.gemini\antigravity\brain\193c207a-e314-4d88-9c01-f329a6af86ea\global_stats_downsample.json'
with open(out_path, 'w') as f:
    json.dump({'dem': dem_stats, 'cost': cost_stats}, f)
print('DONE')
