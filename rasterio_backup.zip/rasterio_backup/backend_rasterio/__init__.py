# Minimal stub implementation of rasterio for the test environment
import numpy as np
from pathlib import Path

# Global registry for loaded datasets (path -> (array, transform))
_dataset_registry = {}

class DatasetReader:
    def __init__(self, path: Path):
        self.path = Path(path)
        # Load data from .npz file (created by test helper)
        npz_path = self.path.with_suffix('.npz')
        if not npz_path.is_file():
            raise FileNotFoundError(f"Stub raster file not found: {npz_path}")
        data = np.load(npz_path)
        self._array = data['data']
        self.transform = tuple(data['transform'])
        self.height, self.width = self._array.shape

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        return False

    def read(self, index: int, window=None):
        # ignore index (only one band)
        if window is None:
            return self._array
        # window is a Window object with .row_off, .col_off, .height, .width
        row_start = window.row_off
        row_end = row_start + window.height
        col_start = window.col_off
        col_end = col_start + window.width
        return self._array[row_start:row_end, col_start:col_end]

def open(path):
    return DatasetReader(Path(path))

# Transform utilities
def xy(transform, rows, cols):
    # transform is a 6‑tuple affine (a, b, c, d, e, f)
    a, b, c, d, e, f = transform
    xs = [c + col * a + row * b for row, col in zip(rows, cols)]
    ys = [f + col * d + row * e for row, col in zip(rows, cols)]
    return xs, ys

# windows submodule
class _Window:
    def __init__(self, row_off, col_off, height, width):
        self.row_off = row_off
        self.col_off = col_off
        self.height = height
        self.width = width

    @staticmethod
    def from_slices(row_slice, col_slice):
        row_start, row_stop = row_slice
        col_start, col_stop = col_slice
        height = row_stop - row_start
        width = col_stop - col_start
        return _Window(row_start, col_start, height, width)

windows = type('windows', (), {'Window': _Window})

# Export needed names
__all__ = ['open', 'transform', 'windows']
