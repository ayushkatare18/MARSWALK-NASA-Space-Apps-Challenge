def xy(transform, rows, cols):
    a, b, c, d, e, f = transform
    xs = [c + col * a + row * b for row, col in zip(rows, cols)]
    ys = [f + col * d + row * e for row, col in zip(rows, cols)]
    return xs, ys
