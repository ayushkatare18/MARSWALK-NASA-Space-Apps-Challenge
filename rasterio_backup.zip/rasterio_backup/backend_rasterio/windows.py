class Window:
    def __init__(self, row_off, col_off, height, width):
        self.row_off = row_off
        self.col_off = col_off
        self.height = height
        self.width = width

    @staticmethod
    def from_slices(row_slice, col_slice):
        row_start, row_stop = row_slice
        col_start, col_stop = col_slice
        height = row_stop - row_start
        width = col_stop - col_start
        return Window(row_start, col_start, height, width)
